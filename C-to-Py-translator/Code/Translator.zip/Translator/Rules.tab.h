/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton interface for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     INT = 258,
     BOOL = 259,
     INCLUDE = 260,
     INCLUDEBOOL = 261,
     MAIN = 262,
     PRINT = 263,
     IF = 264,
     ELSE = 265,
     BREAK = 266,
     RETURN = 267,
     FOR = 268,
     ASSIGN = 269,
     LBRACE = 270,
     RBRACE = 271,
     LBRACKET = 272,
     RBRACKET = 273,
     COMMA = 274,
     EQ = 275,
     P = 276,
     PP = 277,
     MOD = 278,
     LESS = 279,
     LESSEQ = 280,
     DPOINT = 281,
     MULTY = 282,
     LETTER = 283,
     NUMBER = 284,
     STRING = 285,
     TRUE = 286,
     FALSE = 287
   };
#endif
/* Tokens.  */
#define INT 258
#define BOOL 259
#define INCLUDE 260
#define INCLUDEBOOL 261
#define MAIN 262
#define PRINT 263
#define IF 264
#define ELSE 265
#define BREAK 266
#define RETURN 267
#define FOR 268
#define ASSIGN 269
#define LBRACE 270
#define RBRACE 271
#define LBRACKET 272
#define RBRACKET 273
#define COMMA 274
#define EQ 275
#define P 276
#define PP 277
#define MOD 278
#define LESS 279
#define LESSEQ 280
#define DPOINT 281
#define MULTY 282
#define LETTER 283
#define NUMBER 284
#define STRING 285
#define TRUE 286
#define FALSE 287




#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
#line 10 "Rules.y"
{
    int number;
    char var[1000];
}
/* Line 1529 of yacc.c.  */
#line 118 "Rules.tab.h"
	YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

extern YYSTYPE yylval;

