#include <stdio.h>
#include <stdbool.h>
int main() {
    int lower = 10, upper = 100;
    int i,j;
    bool isPrime;               
    printf("%d %d", lower, upper);
    for (i = lower; i <= upper; i++) {
        isPrime = true;
        if (i <= 1) {
            isPrime = false;
        } else {
            for (j = 2; j * j <= i; j++) {
                if (i % j == 0) {
                    isPrime = false;
                    break;
                }
            }
        }
        if (isPrime) {
            printf("%d ", i);
        }
    }
    printf("\nFinish program");
    return 0;
}
