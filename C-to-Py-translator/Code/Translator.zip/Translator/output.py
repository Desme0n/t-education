lower=10; upper=100
print(lower,upper)
for i in range(lower, upper+1):
	isPrime=True
	if i<=1:
		isPrime=False
	else:
		for j in range(2, int(i**0.5)+1):
			if i%j==0:
				isPrime=False
				break
	if isPrime:
		print(i)

print("\nFinish program")

