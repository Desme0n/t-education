﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Security.RightsManagement;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Automation;
using System.Windows.Automation.Text;

namespace SnakeKP
{
    public class GameState
    {
        public int Rows { get; }
        public int Cols { get; }
        /// <summary> двумерный массив имитирует поле </summary>
        /// <returns></returns>
        public GridValue[,] Grid { get; }
        public Direction Dir { get; private set; }//направление
        public int Score { get; private set; } //оценочное поле
        public bool GameOver { get; set; } //статус игры
        /// <summary> двусвязный список, спискок элементов змеи, первый-голова, последний-хвост </summary>
        /// <returns></returns>
        private readonly LinkedList<Direction> dirChanges = new LinkedList<Direction>();
        private readonly LinkedList<Position> snakePosition = new LinkedList<Position>();
        private readonly Random random = new Random();

        public GameState(int rows, int cols)
        {
            Rows = rows;
            Cols = cols;
            Grid = new GridValue[rows, cols];
            Dir = Direction.Right;

            AddSnake();
            AddFood();
        }

        private void AddSnake() //начальное положение змеи, центр поля, Начальная длина = 3;
        {
            int r = Rows / 2;
            for (int c = 1; c <= 3; c++)
            {
                Grid[r, c] = GridValue.Snake;
                snakePosition.AddFirst(new Position(r, c));
            }
        }

        //создание метода, который будет определять пустые позиции
        private IEnumerable<Position> EmptyPositions()
        {
            for (int r = 0; r < Rows; r++)
            {
                for (int c = 0; c < Cols; c++)
                {
                    if (Grid[r, c] == GridValue.Empty)
                    {
                        yield return new Position(r, c);
                    }
                }
            }
        }
        /// <summary> генерация точек </summary>
        /// <returns></returns>
        private void AddFood()
        {
            //список - пустые ячейки массива 
            List<Position> empty = new List<Position>(EmptyPositions());

            //если все поля заняты
            if (empty.Count == 0) { return; }

            //генерация точки на случайной пустой клетке
            Position pos = empty[random.Next(empty.Count)];
            GridValue foodType = GetRandomFoodType();
            Grid[pos.Row, pos.Col] = foodType;
        }
        private GridValue GetRandomFoodType()
        {
            int buf = random.Next(0, 3);
            switch (buf)
            {
                case 0:
                    return GridValue.Food0;
                case 1:
                    return GridValue.Food1;
                case 2:
                    return GridValue.Food2;
                default:
                    // Возвращаем значение по умолчанию или можем бросить исключение
                    return GridValue.Food0; // Или другое значение по умолчанию
            }
        }

        public Position HeadPosition()
        {
            return snakePosition.First.Value;
        }
        public Position TailPosition()
        {
            return snakePosition.Last.Value;
        }

        public IEnumerable<Position> SnakePositions()
        {
            return snakePosition;

        }
        private void AddHead(Position pos)
        {
            snakePosition.AddFirst(pos);
            Grid[pos.Row, pos.Col] = GridValue.Snake;
        }
        private void RemoveTail()
        {
            //перемещение хвоста 
            Position tail = snakePosition.Last.Value;
            Grid[tail.Row, tail.Col] = GridValue.Empty;
            snakePosition.RemoveLast();
        }

        private Direction GetLastDirection()
        {
            if (dirChanges.Count == 0)
            {
                return Dir;
            }
            return dirChanges.Last.Value;
        }
        private bool CanChangeDirection(Direction newDir)
        {
            if (dirChanges.Count == 2)
            {
                return false;
            }
            Direction lastDir = GetLastDirection();
            return newDir != lastDir && newDir != lastDir.Opposite();
        }
        public void ChangeDirection(Direction dir)
        {
            if (CanChangeDirection(dir)) //!
            {
                dirChanges.AddLast(dir);
            }
        }

        private bool OutsideGrid (Position pos)
        {
            return pos.Row < 0 || pos.Row >= Rows || pos.Col < 0 || pos.Col >=  Cols;
        }

        private GridValue WillHit(Position newHeadPos)
        {
            if (OutsideGrid(newHeadPos)) //решение при попытке выйти за границы
            { return GridValue.Outside; }
            if (newHeadPos == TailPosition()) //решение ситуации если в новой позиции головы хвост
            { return GridValue.Empty; }
            return Grid[newHeadPos.Row, newHeadPos.Col]; //вернуть значение сетки нового положения головы
        }

        public void Move()
        {
            if (dirChanges.Count > 0)
            {
                Dir = dirChanges.First.Value;
                dirChanges.RemoveFirst();
            }
            Position newHeadPos = HeadPosition().Translate(Dir);
            GridValue hit = WillHit(newHeadPos);

            if (hit == GridValue.Outside || hit == GridValue.Snake) { GameOver = true; }
            else if (hit == GridValue.Empty)
            {
                RemoveTail();
                AddHead(newHeadPos);
            }
            else if (hit == GridValue.Food0 || hit == GridValue.Food1 || hit == GridValue.Food2)
            {
                AddHead(newHeadPos);
                Score++;
                AddFood();
            }
        }
    }
}
