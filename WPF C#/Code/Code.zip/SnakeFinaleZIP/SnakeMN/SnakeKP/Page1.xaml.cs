﻿using System;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Navigation;
using System.IO;
using System.Linq;

namespace SnakeKP
{
    /// <summary>
    /// Логика взаимодействия для Page1.xaml
    /// </summary>
    public partial class Page1 : Page
    {
        private readonly MainWindow Window;
        public Page1(MainWindow window)
        {
            InitializeComponent();
            Window = window;
            Window.Focusable = true;
            Window.Focus();

            FocusManager.SetFocusedElement(this, null);
        }
        private void TextBox_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter && !string.IsNullOrEmpty(TextBoxName1.Text) && TextBoxName1.Text.Length < 13)
            {

                Page2 page2 = new Page2(Window);
                NavigationService.Navigate(page2);
                string name;
                if (TextBoxName1.Text.Length > 10)
                    TextBoxName1.Text = "";
                else { 
                    name = TextBoxName1.Text;
                    WriteStringToFile("buf2.bin", name);
                }
            }
        }
        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
        private void HelpButton_Click(object sender, RoutedEventArgs e)
        {
            Page3 page3 = new();
            NavigationService.Navigate(page3);

        }
        static void WriteStringToFile(string filePath, string text)
        {
            try
            {
                File.WriteAllText(filePath, text, Encoding.UTF8);
                Console.WriteLine("Запись в файл успешна.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка записи в файл: {ex.Message}");
            }
        }
       
    }
}
