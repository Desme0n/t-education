﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Navigation;

namespace SnakeKP
{
    /// <summary>
    /// элементы управления сетки игры, логика работы для MainWindow.xaml
    /// </summary>
    /// <return> </return>
    public partial class Page2 : Page
    {
        private readonly Dictionary<GridValue, ImageSource> gridValToImage = new()
        {
            { GridValue.Empty, Images.Empty },
            { GridValue.Snake, Images.Body },
            { GridValue.Food0, Images.Food0},
            { GridValue.Food1, Images.Food1},
            { GridValue.Food2, Images.Food2}
        };

        private readonly Dictionary<Direction, int> dirToRotation = new()
        {
            { Direction.Up, 0},
            { Direction.Down, 180},
            { Direction.Left, 270},
            { Direction.Right, 90}
        };

        private readonly int rows = 15, cols = 15;
        /// <summary>массив, текстура поля</summary>
        /// <return> </return>
        private readonly Image[,] gridImages;
        private GameState gameState;
        private bool gameRunning;
        private bool pause = false;
        private readonly MainWindow Window;
        public Page2(MainWindow window)
        {

            InitializeComponent();

            Window = window;
            Window.PreviewKeyDown += PagePreviewKeyDown;
            Window.KeyDown += PageKeyDown;
            Window.Focusable = true;
            Window.Focus();
            gridImages = SetupGrid();
            gameState = new GameState(rows, cols);
        }
        private void GoBack_Click(object sender, RoutedEventArgs e)
        {
            Window.PreviewKeyDown -= PagePreviewKeyDown;
            Window.KeyDown -= PageKeyDown;
            gameState.GameOver = true;
            NavigationService.GoBack();
        }

        public void PageKeyDown(object sender, KeyEventArgs e)
        {
            if (gameState.GameOver)
            {
                return;
            }
            switch (e.Key)
            {
                case Key.Left:
                case Key.A:
                    gameState.ChangeDirection(Direction.Left);
                    break;
                case Key.Right:
                case Key.D:
                    gameState.ChangeDirection(Direction.Right);
                    break;
                case Key.Up:
                case Key.W:
                    gameState.ChangeDirection(Direction.Up);
                    break;
                case Key.Down:
                case Key.S:
                    gameState.ChangeDirection(Direction.Down);
                    break;
                case Key.Space:
                case Key.Escape:
                    pause = !pause;
                    break;

            }

        }
        private Image[,] SetupGrid()    // метод добавления изображений в сетку игры, возвращает готовое поле
        {
            Image[,] images = new Image[rows, cols];
            GameGrid.Rows = rows;
            GameGrid.Columns = cols;

            for (int r = 0; r < rows; r++)
            {
                for (int c = 0; c < cols; c++)
                {
                    Image image = new()
                    {
                        Source = Images.Empty,
                        RenderTransformOrigin = new Point(0.5, 0.5)
                    };
                    images[r, c] = image;
                    GameGrid.Children.Add(image);
                }
            }
            return images;

        }
        private void Draw()
        {
            DrawGrid();
            DrawSnakeHead();
            ScoreText.Text = $"SCORE {gameState.Score}";
        }
        private void DrawGrid()
        {
            for (int r = 0; r < rows; r++)
            {
                for (int c = 0; c < cols; c++)
                {
                    GridValue gridVal = gameState.Grid[r, c];
                    gridImages[r, c].Source = gridValToImage[gridVal];
                    gridImages[r, c].RenderTransform = Transform.Identity;
                }
            }
        }

        private void DrawSnakeHead()
        {
            Position headPos = gameState.HeadPosition();
            Image image = gridImages[headPos.Row, headPos.Col];
            image.Source = Images.Head;

            int rotation = dirToRotation[gameState.Dir];
            image.RenderTransform = new RotateTransform(rotation);
        }

        private async Task DrawDeadSnake()
        {
            List<Position> positions = new List<Position>(gameState.SnakePositions());

            for (int i = 0; i < positions.Count; i++)
            {
                Position pos = positions[i];
                ImageSource source = (i == 0) ? Images.DeadHead : Images.DeadBody;
                gridImages[pos.Row, pos.Col].Source = source;
                await Task.Delay(200);
            }
        }
        private async Task ShowCountDown()
        {
            for (int i = 3; i >= 1; i--)
            {
                OverlayText.Text = i.ToString();
                await Task.Delay(500);
            }
        }
        private async Task ShowCountDownPause()
        {
            for (int i = 3; i >= 1; i--)
            {
                PauseText.Text = i.ToString();
                await Task.Delay(500);
            }
        }
        private async Task RunGame()
        {

            PauseBorder.Visibility = Visibility.Hidden;
            Draw();
            await ShowCountDown();
            Overlay.Visibility = Visibility.Hidden;
            await GameLoop();
            await ShowGameOver();
            WriteStringToFile("buf.bin", gameState.Score.ToString());//////////////////////////////////////////////////////////////
            WriteStringToFile("buf3.bin", "1");
            gameState = new GameState(rows, cols);
        }
        public async void PagePreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (Overlay.Visibility == Visibility.Visible)
            {
                e.Handled = true;
            }
            if (!gameRunning)
            {
                gameRunning = true;
                await RunGame();
                gameRunning = false;
            }
        }

        private async Task GameLoop()
        {
            while (!gameState.GameOver)
            {
                if (!pause)
                {
                    await Task.Delay(100);
                    gameState.Move();
                    Draw();
                }
                else
                {
                    PauseBorder.Visibility = Visibility.Visible;
                    PauseText.Text = "PRESS ESCAPE/SPACE TO CONTINUE";
                    PauseText.Visibility = Visibility.Visible;
                    // Ожидание выхода из режима паузы
                    await WaitForResume();
                    await ShowCountDownPause();
                    PauseBorder.Visibility = Visibility.Hidden;

                }
            }
        }

        public async Task WaitForResume()
        {
            while (pause)
            {
                await Task.Delay(100);
            }
        }


        private async Task ShowGameOver()
        {
            await DrawDeadSnake();
            await Task.Delay(1000);
            Overlay.Visibility = Visibility.Visible;
            OverlayText.Text = "PRESS ANY KEY TO START";

        }

        static void WriteStringToFile(string filePath, string text)
        {
            try
            {
                File.WriteAllText(filePath, text, Encoding.UTF8);
                Console.WriteLine("Запись в файл успешна.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка записи в файл: {ex.Message}");
            }
        }

    
    }
}


