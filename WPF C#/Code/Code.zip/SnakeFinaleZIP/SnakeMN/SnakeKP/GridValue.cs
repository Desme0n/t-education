﻿
namespace SnakeKP
{
    public enum GridValue
    {
        Empty,
        Snake,
        Outside,
        //три типа еды:
        Food0, 
        Food1, 
        Food2,
    }

}
