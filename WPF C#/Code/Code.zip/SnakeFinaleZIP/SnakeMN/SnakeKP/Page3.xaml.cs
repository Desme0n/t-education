﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Windows;
using System.Windows.Controls;

namespace SnakeKP
{
    /// <summary>
    /// Логика взаимодействия для Page3.xaml
    /// </summary>
    public partial class Page3 : Page
    {
        private string statusName;  // инофрмация об игре сохраняется всего один раз, хранится в файле

        [Serializable]
        private struct gameHistory
        {
            public string name;
            public string point;
        }
        private  LinkedList<gameHistory> RecordList = new LinkedList<gameHistory>();
        private  LinkedList<gameHistory> GameHistory = new LinkedList<gameHistory>();

        public Page3()
        {
            InitializeComponent();
            //NameBlock = this.NameBlock;

            string history = "history.bin";
            string record = "records.bin";
            
            ReadHistoryFromFile(history);
            ReadRecordFromFile(record);

            string score = ReadStringFromFile("buf.bin");
            string name = ReadStringFromFile("buf2.bin");

            statusName = ReadStringFromFile("buf3.bin");
            if (statusName == "1")
            {
                AddGameHistory(name, score);
            }


            WriteHistoryToFile(history);
            ReadHistoryFromFile(history);

            CompareRecord(name, score);
            WriteRecordToFile(record);

            WriteStringToFile("buf.bin", "");
            WriteStringToFile("buf2.bin", "");
            WriteHistoryBlock();
            WriteRecordBlock();
        }
        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            string history = "history.bin";
            string record = "records.bin";
            RecordList.Clear();
            GameHistory.Clear();
            WriteHistoryToFile(history);
            WriteRecordToFile(record);
            WriteHistoryBlock();
            WriteRecordBlock();
        }
        private void GoBack_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }

        private void WriteHistoryBlock()
        {
            StringBuilder stringBuilder1 = new StringBuilder();
            StringBuilder stringBuilder2 = new StringBuilder();

            foreach (var historyEntry in GameHistory)
            {
                stringBuilder1.AppendLine($"{historyEntry.name}");

                stringBuilder2.AppendLine($"{historyEntry.point}");
            }

            HistoryNameBlock.Text = stringBuilder1.ToString();
            HistoryScoreBlock.Text = stringBuilder2.ToString();
        }
        private void WriteRecordBlock()
        {
            StringBuilder stringBuilder1 = new StringBuilder();
            StringBuilder stringBuilder2 = new StringBuilder();

            foreach (var RecordEntry in RecordList)
            {
                stringBuilder1.AppendLine($"{RecordEntry.name}");

                stringBuilder2.AppendLine($"{RecordEntry.point}");
            }

            RecordNameBlock.Text = stringBuilder1.ToString();
            RecordScoreBlock.Text = stringBuilder2.ToString();
        }

        private void WriteStringToFile(string filePath, string text)
        {
            try
            {
                File.WriteAllText(filePath, text, Encoding.UTF8);
                Console.WriteLine("Запись в файл успешна.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка записи в файл: {ex.Message}");
            }
        }

        private string ReadStringFromFile(string filePath)
        {
            try
            {
                if (File.Exists(filePath))
                {
                    return File.ReadAllText(filePath, Encoding.UTF8);
                }
                else
                {
                    Console.WriteLine("Файл не найден.");
                    return string.Empty;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка чтения из файла: {ex.Message}");
                return string.Empty;
            }
        }
        private void WriteHistoryToFile(string filePath)
        {
            try
            {
                using (FileStream fs = new FileStream(filePath, FileMode.Create))
                {
                    BinaryFormatter formatter = new BinaryFormatter();
                    formatter.Serialize(fs, GameHistory.ToList());
                }
                Console.WriteLine("Write to file successful.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error writing to file: {ex.Message}");
            }
        }
        private void WriteRecordToFile(string filePath)
        {
            try
            {
                using (FileStream fs = new FileStream(filePath, FileMode.Create))
                {
                    BinaryFormatter formatter = new BinaryFormatter();
                    formatter.Serialize(fs, RecordList.ToList());
                }
                Console.WriteLine("Write to file successful.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error writing to file: {ex.Message}");
            }
        }

        private void ReadHistoryFromFile(string filePath)
        {
            try
            {
                if (File.Exists(filePath))
                {
                    using (FileStream fs = new FileStream(filePath, FileMode.Open))
                    {
                        BinaryFormatter formatter = new BinaryFormatter();
                        var loadedHistories = (List<gameHistory>)formatter.Deserialize(fs);

                        // Ограничиваем количество считываемых элементов до 5
                        var firstFiveHistories = loadedHistories.Take(10).ToList();

                        GameHistory = new LinkedList<gameHistory>(firstFiveHistories);
                    }
                }
                else
                {
                    Console.WriteLine("File not found.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error reading from file: {ex.Message}");
            }
        }
        private void ReadRecordFromFile(string filePath)
        {
            try
            {
                if (File.Exists(filePath))
                {
                    using (FileStream fs1 = new FileStream(filePath, FileMode.Open))
                    {
                        BinaryFormatter formatter1 = new BinaryFormatter();
                        var loadedRecords = (List<gameHistory>)formatter1.Deserialize(fs1);

                        // Ограничиваем количество считываемых элементов до 5
                        var buf = loadedRecords.Take(10).ToList();

                        RecordList = new LinkedList<gameHistory>(buf);
                    }
                }
                else
                {
                    Console.WriteLine("File not found.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error reading from file: {ex.Message}");
            }
        }

        private void AddGameHistory(string playerName, string pointName) // добавить в игровую историю
        {
            gameHistory historyEntry = new gameHistory
            {
                name = playerName,
                point = pointName
            };

            GameHistory.AddFirst(historyEntry);
            WriteStringToFile("buf3.bin", "0");
        }
        public void CompareRecord(string name, string score)
        {
            // Проверяем, что и score, и name не являются пустыми строками
            if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(score))
            {
                // Обработка случая, когда name или score пустые
                Console.WriteLine("Name or score is empty or contains only white spaces.");
                return;
            }
            // Пытаемся преобразовать score в число
            if (int.TryParse(score, out int newScore))
            {
                // Создаем новый объект gameHistory
                gameHistory newRecord = new gameHistory { name = name, point = newScore.ToString() };

                // Находим позицию, на которую следует вставить новый элемент
                LinkedListNode<gameHistory> curNode = RecordList.First;
                while (curNode != null && newScore <= Convert.ToInt32(curNode.Value.point))
                {
                    curNode = curNode.Next;
                }
                // Вставляем новый элемент на найденную позицию
                if (curNode != null)
                {
                    RecordList.AddBefore(curNode, newRecord);
                }
                else
                {
                    RecordList.AddLast(newRecord);
                }
            }
            else
            {
                Console.WriteLine("Invalid score format. Score must be a valid integer.");
            }
        }
        
    }
}
